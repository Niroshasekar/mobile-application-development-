package com.example.tvchannelapp;
public class playerconfig {
    playerconfig()
    {
    }
    public static final String
            API_KEY="AIzaSyCBMfw7l2n0uyXRPjmp_TpeDsGGpyFdwUs";
}