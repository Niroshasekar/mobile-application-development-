package com.example.googlesheet;
import org.json.JSONObject;


interface AsyncResult
{
    void onResult(JSONObject object);
}